# Importing libraries
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split

from sklearn.feature_extraction.text import TfidfVectorizer

# confusion matrix, classification accuracy, f1-score, precision, and recall
from sklearn.metrics import confusion_matrix, classification_report, accuracy_score, f1_score, precision_score, recall_score

import emoji
import re
from ekphrasis.classes.preprocessor import TextPreProcessor
from ekphrasis.classes.tokenizer import SocialTokenizer

import string
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
import pickle

dataset = pd.read_csv("CL-2-Test-Quora-Question-Pair - Sheet1.csv")

# # Task 2: Preprocess the data
# # use the ekphrasis library to preprocess the text
# text_processor = TextPreProcessor(
#     # terms that will be annotated
#     annotate={"hashtag"},

#     # corpus from which the word statistics are going to be used
#     # for word segmentation
#     segmenter="twitter",

#     # corpus from which the word statistics are going to be used
#     # for spell correction
#     corrector="twitter",

#     unpack_hashtags=True,  # perform word segmentation on hashtags

#     # select a tokenizer. You can use SocialTokenizer, or pass your own
#     # the tokenizer, should take as input a string and return a list of tokens
#     tokenizer=SocialTokenizer(lowercase=True).tokenize,
# )

# def ekphrasisPreprocess(text):
#     text = ' '.join(text_processor.pre_process_doc(text))

#     return text

# Function to remove the punctuation marks and convert the words to lower case
def removePunctuationConvertLower(wordTokens):
    wordTokensPunctuationRemoved = []
    for wordToken in wordTokens:
        if wordToken not in string.punctuation:
            wordTokensPunctuationRemoved.append(wordToken.lower())
    return wordTokensPunctuationRemoved

# Function to remove stop words if any
def removeStopWords(wordTokensPunctuationRemoved):
    wordTokensStopWordsRemoved = []
    defaultStopWords = set(stopwords.words('english'))
    for wordToken in wordTokensPunctuationRemoved:
            if wordToken not in defaultStopWords:
                wordTokensStopWordsRemoved.append(wordToken)
    return wordTokensStopWordsRemoved

# Function to convert emojis to text and remove # from hashtags
def convertEmojisAndRemoveHashTags(documentTextEmojisAndHashTagProcessed):
    #documentTextEmojisAndHashTagProcessed = re.sub(r'#', '', documentText)
    documentTextEmojisAndHashTagProcessed = emoji.demojize(documentTextEmojisAndHashTagProcessed)
    return documentTextEmojisAndHashTagProcessed

# Function to lemmatize words
def lemmatizeWords(wordTokensStopWordsRemoved):
    defaultLemmatizer = WordNetLemmatizer()
    lemmatizedWords = []
    for wordToken in wordTokensStopWordsRemoved:
        lemmatizedWords.append(defaultLemmatizer.lemmatize(wordToken))
    return lemmatizedWords

# Helper method to clean data
def processDocument(documentText):

    documentTextEmojisAndHashTagProcessed = convertEmojisAndRemoveHashTags(documentText)

    # # Applying ekphrasis preprocessing
    # documentTextEmojisAndHashTagProcessed = ekphrasisPreprocess(documentTextEmojisAndHashTagProcessed)

    wordTokens = word_tokenize(documentTextEmojisAndHashTagProcessed)

    wordTokensPunctuationRemoved = removePunctuationConvertLower(wordTokens)
    
    wordTokensStopWordsRemoved = removeStopWords(wordTokensPunctuationRemoved)
    
    lemmatizedTokens = lemmatizeWords(wordTokensStopWordsRemoved)

    # Joining the lemmatized tokens to form the document text
    lemmatizedTokens = ' '.join(lemmatizedTokens)

    return lemmatizedTokens

# def changeLabel(label):
#     if label != 1 and label != 0:
#         print(label)


# Preprocessing the training data
dataset['question1'] = dataset['question1'].apply(processDocument)
dataset['question2'] = dataset['question2'].apply(processDocument)

# dataset['is_duplicate'] = dataset['is_duplicate'].apply(changeLabel)






dataset.to_csv("Preprocessed_input.csv", index = False)
