# Importing libraries
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split, KFold, cross_val_score, RandomizedSearchCV

# different models K-nearest Neighbor, Logistic Regression, Support Vector Machine, K-Means Clustering, Neural Networks, fastText
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from sklearn.cluster import KMeans
from sklearn.neural_network import MLPClassifier

from sklearn.feature_extraction.text import TfidfVectorizer
import pickle

with open('Features_train.npy', 'rb') as f:
    trainFeatures = pickle.load(f)

with open('y_train.pkl', 'rb') as f:
    y_train = pickle.load(f)

models = {
    'LR': LogisticRegression(),
    'SVM': SVC(),
    'NN': MLPClassifier()
}

fileName = ['LogisticRegression.pkl', 'svm.pkl', 'NeuralNetwork.pkl']

trainFeaturesNumpy = np.array(trainFeatures)
y_trainNumpy = np.array(y_train)

i=0
for model in models:
    print(f"Training {model} model")
    models[model].fit(trainFeaturesNumpy, y_trainNumpy)

    filename = fileName[i]
    pickle.dump(models[model], open(filename, "wb"))
    i = i+1
