# Importing libraries
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split

from sklearn.feature_extraction.text import TfidfVectorizer

# confusion matrix, classification accuracy, f1-score, precision, and recall
from sklearn.metrics import confusion_matrix, classification_report, accuracy_score, f1_score, precision_score, recall_score

import emoji
import re
from ekphrasis.classes.preprocessor import TextPreProcessor
from ekphrasis.classes.tokenizer import SocialTokenizer

import string
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
import pickle

dataset = pd.read_csv("Preprocessed_input.csv")
dataset.fillna("TextMissing", inplace=True)

# print(dataset.dtypes)

trainDataset, testDataset = train_test_split(dataset, train_size = 0.8, test_size = 0.2, random_state = 42, shuffle=True)
trainDataset.to_csv("Train.csv", index = False)
testDataset.to_csv("Test.csv", index = False)

tdIdfVectorizer = TfidfVectorizer(max_features=100, ngram_range=(0, 2))

# Change the train data to vector form
tdIdfVectorizer.fit(pd.concat([trainDataset['question1'], trainDataset['question2']]))

X_train_Q1 = tdIdfVectorizer.transform(trainDataset['question1'])
X_train_Q2 = tdIdfVectorizer.transform(trainDataset['question2'])
Y_train = trainDataset['is_duplicate']

X_Test_Q1  = tdIdfVectorizer.transform(testDataset['question1'])
X_Test_Q2  = tdIdfVectorizer.transform(testDataset['question2'])
Y_test = testDataset['is_duplicate']

outputdictTrain = {}

# For training
for i in range(X_Test_Q1.shape[0]):
    newDict = {}
    newDict[0] = X_train_Q1[i]
    newDict[1] = X_train_Q2[i]
    outputdictTrain[i] = newDict

# For testing
outputdictTest = {}
for i in range(X_Test_Q1.shape[0]):
    newDict = {}
    newDict[0] = X_Test_Q1[i]
    newDict[1] = X_Test_Q2[i]
    outputdictTest[i] = newDict

pickle.dump(outputdictTrain, open("train_representation.pkl", "wb"))
pickle.dump(outputdictTest, open("test_representation.pkl", "wb"))

pickle.dump(Y_train, open("y_train.pkl", "wb"))
pickle.dump(Y_test, open("y_test.pkl", "wb"))

# print(outputdict[0])