# Importing libraries
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split

from sklearn.feature_extraction.text import TfidfVectorizer

# confusion matrix, classification accuracy, f1-score, precision, and recall
from sklearn.metrics import confusion_matrix, classification_report, accuracy_score, f1_score, precision_score, recall_score

import emoji
import re
from ekphrasis.classes.preprocessor import TextPreProcessor
from ekphrasis.classes.tokenizer import SocialTokenizer

import string
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
import pickle

with open('train_representation.pkl', 'rb') as f:
    trainDataVectors = pickle.load(f)

with open('test_representation.pkl', 'rb') as f:
    testDataVectors = pickle.load(f)

trainDataframe = dataset = pd.read_csv("Train.csv")
testDataframe = dataset = pd.read_csv("Test.csv")

# print(trainDataframe.head())
# Function to remove stop words if any
def removeStopWords(wordTokensPunctuationRemoved):
    wordTokensStopWordsRemoved = []
    defaultStopWords = set(stopwords.words('english'))
    for wordToken in wordTokensPunctuationRemoved:
            if wordToken not in defaultStopWords:
                wordTokensStopWordsRemoved.append(wordToken)
    return wordTokensStopWordsRemoved

# print(len(vectors))

def featureExtraction(dataframe, vectors):
    features = []

    for i in range(dataframe.shape[0]):
        # try:
            feature = []
            question1 = dataframe.iloc[i][0]
            question2 = dataframe.iloc[i][1]

            question1Words = question1.split()
            question2Words = question2.split()

            question1WordsWithoutStop = removeStopWords(question1Words)
            question2WordsWithoutStop = removeStopWords(question2Words)

            q1_char_num = len(question1)
            q2_char_num = len(question2)
            feature.append(q1_char_num)
            feature.append(q2_char_num)


            q1_word_num = len(question1.split())
            q2_word_num = len(question2.split())
            feature.append(q1_word_num)
            feature.append(q2_word_num)

            total_word_num = q1_word_num + q2_word_num
            feature.append(total_word_num)

            differ_word_num = abs(q1_word_num - q2_word_num)
            feature.append(differ_word_num)

            same_first_word = 0
            if question1.split()[0] == question2.split()[0]:
                same_first_word = 1
            feature.append(same_first_word)

            same_last_word = 0
            if question1.split()[-1] == question2.split()[-1]:
                same_last_word = 1
            feature.append(same_last_word)

            total_unique_word_num = len(set(question1.split())) + len(set(question2.split()))
            feature.append(total_unique_word_num)


            total_unique_word_withoutstopword_num = len(set(question1WordsWithoutStop).union(set(question2WordsWithoutStop)))
            feature.append(total_unique_word_withoutstopword_num)

            total_unique_word_num_ratio = total_unique_word_num/ total_word_num
            feature.append(total_unique_word_num_ratio)

            common_word_num = 0
            for word in question1Words:
                if word in question2Words:
                    common_word_num + 1

            common_word_ratio = common_word_num/total_unique_word_num
            feature.append(common_word_ratio)

            common_word_withoutstopword_num = 0
            for word in question1WordsWithoutStop:
                if word in question2WordsWithoutStop:
                    common_word_num + 1

            feature.append(common_word_withoutstopword_num)

            # feature.append(vectors[i][0])
            # feature.append(vectors[i][1])
        # except:
        #     continue

            features.append(feature)
    
    return features


train = featureExtraction(trainDataframe, trainDataVectors)
test = featureExtraction(testDataframe, testDataVectors)

print(len(train))
print(len(test))

pickle.dump(train, open("Features_train.npy", "wb"))
pickle.dump(test, open("Features_Test.npy", "wb"))