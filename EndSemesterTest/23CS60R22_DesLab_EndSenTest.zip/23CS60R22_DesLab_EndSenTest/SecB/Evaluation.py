# Importing libraries
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split, KFold, cross_val_score, RandomizedSearchCV

# different models K-nearest Neighbor, Logistic Regression, Support Vector Machine, K-Means Clustering, Neural Networks, fastText
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from sklearn.cluster import KMeans
from sklearn.neural_network import MLPClassifier

from sklearn.feature_extraction.text import TfidfVectorizer
import pickle

# confusion matrix, classification accuracy, f1-score, precision, and recall
from sklearn.metrics import confusion_matrix, classification_report, accuracy_score, f1_score, precision_score, recall_score



with open('Features_Test.npy', 'rb') as f:
    testFeatures = pickle.load(f)

with open('y_test.pkl', 'rb') as f:
    y_test = pickle.load(f)

modelNames = ["svm.pkl", "NeuralNetwork.pkl", "LogisticRegression.pkl"]

models = []

testFeaturesNumpy = np.array(testFeatures)
y_testNumpy = np.array(y_test)

for modelName in modelNames:
    model = pickle.load(open(modelName, "rb"))
    models.append(model)

    # Predict the test data
    Y_pred = model.predict(testFeaturesNumpy)

    # Getting model type
    modelType = type(model).__name__


    # Output file name
    outputFilename = "output" + modelType + ".txt"

    # Write test performance to file using confusion matrix, classification accuracy, f1-score, precision, and recall
    filename = outputFilename
    with open(filename, 'w') as f:
        f.write("Confusion Matrix:\n")
        f.write(str(confusion_matrix(y_testNumpy, Y_pred)) + "\n")
        f.write("Classification Report:\n")
        f.write(str(classification_report(y_testNumpy, Y_pred)) + "\n")
        f.write("Classification Accuracy: \n" + str(accuracy_score(y_testNumpy, Y_pred)) + "\n")
        f.write("F1 Score: " + str(f1_score(y_testNumpy, Y_pred, average='weighted')) + "\n")
        f.write("Precision: " + str(precision_score(y_testNumpy, Y_pred, average='weighted')) + "\n")
        f.write("Recall: " + str(recall_score(y_testNumpy, Y_pred, average='weighted')) + "\n")
        f.close()


