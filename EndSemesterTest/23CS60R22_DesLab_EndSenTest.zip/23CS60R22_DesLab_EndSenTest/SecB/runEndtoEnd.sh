#!/bin/bash

python3 Preprocessing.py
python3 Representation.py
python3 Features.py
python3 Models.py
python3 Evaluation.py