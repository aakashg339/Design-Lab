with tempTotalOrders1 AS (
    SELECT c.Id, c.FirstName, c.LastName, o.OrderDate, COUNT(o.Id) as TotalOrdersInADay
    FROM Customers AS c INNER JOIN Orders AS o ON c.Id = o.CustomerId
    GROUP BY c.Id, c.FirstName, c.LastName, o.OrderDate
    ORDER BY TotalOrdersInADay DESC
)

SELECT DISTINCT Id, FirstName, LastName
FROM tempTotalOrders1
WHERE TotalOrdersInADay = (SELECT MAX(TotalOrdersInADay) FROM tempTotalOrders1);