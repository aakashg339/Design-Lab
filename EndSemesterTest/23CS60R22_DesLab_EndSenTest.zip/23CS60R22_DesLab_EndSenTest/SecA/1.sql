SELECT c.FirstName, c.LastName, SUM(o.TotalAmount) as TotalSpendAmount
FROM Customers AS c INNER JOIN Orders AS o ON c.Id = o.CustomerId
GROUP BY c.FirstName, c.LastName
ORDER BY TotalSpendAmount DESC
LIMIT 3;